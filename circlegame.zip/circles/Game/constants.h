#ifndef CONSTANTS_H
#define CONSTANTS_H
const float SCREEN_WIDTH = 1400;
const float SCREEN_HEIGHT = 800;
const float WORK_PANEL = SCREEN_WIDTH*4/5;
const float SIDE_BAR = SCREEN_WIDTH*1/5;
#endif // CONSTANTS_H
